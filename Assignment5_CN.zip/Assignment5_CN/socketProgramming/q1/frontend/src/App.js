import React,
{
    useState,
    useEffect
} from 'react';

import io from 'socket.io-client';
import './App.css';

const socket = io('http://localhost:8080'); // Create a socket connection to the server at 'http://localhost:5000'

function App() {

    const [content, setContent] = useState('');
    
    // useEffect hook to handle side effects such as subscribing to socket events
    useEffect(() => {
    
    		// Listen for initial content when connecting
        socket.on('initialContent', (initialData) => {
            // Set document content
            setContent(initialData.document);
        });
    
    
        // Listening for 'updateContent' event from the server
        socket.on('updateContent', (updatedContent) => {
            // When 'updateContent' is received, update the content state with the new text
            setContent(updatedContent);
        });

        return () => {
            socket.off('updateContent');
        };
    });

    // Handle the content editing (whenever the user types in the textarea)
    const handleEdit = (event) => {
        const updatedContent = event.target.value;   // Get the updated content from the textarea
        setContent(updatedContent);                  // Update the local state with the new content
        socket.emit('edit', updatedContent);         // Emit the 'edit' event to the server with the updated content
    };


    return (
        <div className="App">
            <h1>Real-time Collaborative Editor</h1>
            <textarea
                value={content}                  // Bind the textarea value to the 'content' state
                onChange={handleEdit}            // Trigger 'handleEdit' when the textarea value changes
                rows={10}
                cols={50}
            />
        </div>
    );
}

export default App;

