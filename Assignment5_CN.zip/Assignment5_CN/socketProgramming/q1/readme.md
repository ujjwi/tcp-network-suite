#Detailed comments for explaining the code have been added in the code files itself
--server.js is the server implementation in the backend
--App.js is the client implementation in the frontend

#Commands to start collaborative editor:

-- In current terminal, run following commands:

1. cd q1/backend
2. node server.js
// You can see the connection status of different clients on this terminal

-- Now, in another terminal(s), do the following:

1. cd q1/frontend
2. npm start
// It will open multiple editors on multiple port numbers where you edit and see the results

#References :
https://www.geeksforgeeks.org/real-time-collaborative-editing-app-using-react-websockets/
