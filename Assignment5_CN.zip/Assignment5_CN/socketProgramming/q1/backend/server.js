const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const fs = require('fs');
const { Mutex } = require('async-mutex'); 

const app = express();
app.use(cors());

const server = http.createServer(app);

// Setting up the Socket.IO instance on the created HTTP server
const io = socketIo(server, {
    cors: {
        origin: '*',        // Allows connections from any origin (for simplicity in development)
        methods: ['GET', 'POST'],  // Specifies the allowed HTTP methods (GET and POST)
        credentials: true    // Enables passing credentials (cookies, HTTP authentication) with requests
    }
});

// Shared document content in memory
let sharedDocument = '';

// Ensure temp.txt exists and load its content into memory (if any)
try {
  if (fs.existsSync("temp.txt")) {
    sharedDocument = fs.readFileSync("temp.txt", "utf8");
    console.log("Loaded existing document from temp.txt.");
  } else {
    fs.writeFileSync("temp.txt", ""); // Create temp.txt if it doesn't exist
    console.log("temp.txt created.");
  }
} catch (err) {
  console.error("Error opening or creating temp.txt:", err);
}

// Mutex for synchronizing access to sharedDocument and file writes
const mutex = new Mutex();

// Event listener for when a new client connects to the server via WebSocket
io.on('connection', (socket) => {

    // Check for maximum client connections
    if (io.engine.clientsCount > 10) {
        console.log('Maximum client limit reached. Disconnecting client.');
        socket.disconnect();
        return;
    }
    
    // Immediately send the current document state to the newly connected client
    socket.emit('initialContent', {
        document: sharedDocument,
        // You can also send additional state information if needed
        styleState: {
            bold: false,     // Default style states
            italic: false,
            underline: false
        }
    });
    
    console.log('New client connected'); // Logs when a new client has connected

    // Listen for 'edit' events from the client
  socket.on("edit", async (content) => {
    // Use mutex to ensure synchronized access
    await mutex.runExclusive(async () => {
      sharedDocument = content;

      // Write the update to temp.txt
      fs.appendFile("temp.txt", content + "\n", (err) => {
        if (err) {
          console.error("Error writing to temp.txt:", err);
        } else {
          console.log("Document updated and saved to temp.txt");
        }
      });

      // Broadcast the update to all other clients
      socket.broadcast.emit("updateContent", content);
      console.log(`Received update from client ${socket.id}: ${content}`);
      console.log("Broadcasting update to all clients");
    });
  });

    // Listening for the 'disconnect' event which is triggered when a client disconnects
    socket.on('disconnect', () => {
        // Logs when a client disconnects from the server
        console.log('Client disconnected');
        console.log(`Currently connected clients: ${io.engine.clientsCount}`);
    });
});

const PORT = 8080;

server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});

server.on("error", (err) => {
  console.error("Server error: Unable to start server on port 8080", err);
});

