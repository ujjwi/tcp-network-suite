#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#define SERVER_PORT     "3005"
#define BUFFER_LENGTH   1024
#define BACKLOG         10

// Following helper function extracts the IP address from a struct sockaddr.
// AF_INET: IPv4 address
// AF_INET6: IPv6 address
void *get_in_addr(struct sockaddr *sa) {
    if (sa->sa_family == AF_INET) {
        return &(((struct sockaddr_in*)sa)->sin_addr);
    }
    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

int main(void) {
    int sockfd, new_fd;                 // Socket file descriptors
    struct addrinfo hints, *servinfo, *p; // Address information structures
    struct sockaddr_storage their_addr;   // Client address storage
    socklen_t sin_size;                   // Size of client address
    char s[INET6_ADDRSTRLEN];             // String to store client IP
    int rv, yes = 1;                      // Return value and socket option

    memset(&hints, 0, sizeof hints);

    // Use IPv6 socket with support for IPv4-mapped addresses
    hints.ai_family = AF_INET6;     
    hints.ai_socktype = SOCK_STREAM; // Use a TCP socket
    hints.ai_flags = AI_PASSIVE | AI_V4MAPPED | AI_ALL; // Allow the program to use the server's IP automatically

    // Get address information: Resolves the server's IP address and port. Results are stored in servinfo
    if ((rv = getaddrinfo(NULL, SERVER_PORT, &hints, &servinfo)) != 0) {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
        return 1;
    }

    // Tries each result from getaddrinfo until a successful bind
    for (p = servinfo; p != NULL; p = p->ai_next) {
        // Create a socket
        if ((sockfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) {
            perror("server: socket");
            continue;
        }

        // Disable IPv6 only mode to allow IPv4 connections
        int off = 0;
        if (setsockopt(sockfd, IPPROTO_IPV6, IPV6_V6ONLY, &off, sizeof(off)) == -1) {
            perror("setsockopt IPV6_V6ONLY");
            exit(1);
        }

        // Allow socket reuse
        if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1) {
            perror("setsockopt");
            exit(1);
        }

        // Bind socket to the address
        if (bind(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
            close(sockfd);
            perror("server: bind");
            continue;
        }

        // Successful bind
        break;
    }

    // If we went through all address info and could not bind, exit
    if (p == NULL) {
        fprintf(stderr, "server: failed to bind\n");
        exit(1);
    }

    freeaddrinfo(servinfo); // No longer needed

    // Start listening on the socket
    if (listen(sockfd, BACKLOG) == -1) {
        perror("listen");
        exit(1);
    }

    printf("Server is waiting for connections on IPv4 and IPv6...\n");

    // Accept connections loop
    while (1) {
        sin_size = sizeof their_addr;
        new_fd = accept(sockfd, (struct sockaddr *)&their_addr, &sin_size);
        if (new_fd == -1) {
            perror("accept");
            continue;
        }

        // Convert IP to string for printing
        inet_ntop(their_addr.ss_family,
            get_in_addr((struct sockaddr *)&their_addr),
            s, sizeof s);
        printf("server: got connection from %s\n", s);

        // Receive and echo message
        char buffer[BUFFER_LENGTH];
        int numbytes;
        if ((numbytes = recv(new_fd, buffer, BUFFER_LENGTH-1, 0)) == -1) {
            perror("recv");
            close(new_fd);
            continue;
        }
        buffer[numbytes] = '\0';
        printf("Received: %s", buffer);

        // Echo back to client
        if (send(new_fd, buffer, numbytes, 0) == -1) {
            perror("send");
        }

        close(new_fd); // Close connection with client
    }

    close(sockfd); // Close server socket
    return 0;
}
