#Detailed comments for explaining the code have been added in the code files itself
--server.c is the server implementation
--client.c is the client implementation

#Commands to start protocol independent echo server/client:

-- In current terminal, run following commands:

1. cd q3
2. gcc -o server server.c
3. ./server

-- Now, in another terminal(s), do the following:

1. cd q3
2. gcc -o client client.c
3. ./client localhost
3. ./client ip6-localhost
3. ./client ::1
3. ./client 127.0.0.1

#References :
https://www.ibm.com/docs/en/i/7.3?topic=sscaaiic-example-accepting-connections-from-both-ipv6-ipv4-clients
